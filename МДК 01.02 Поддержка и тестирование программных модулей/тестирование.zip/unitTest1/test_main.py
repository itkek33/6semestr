import unittest
from datetime import datetime
from unittest.mock import patch, MagicMock
from main import StudentLibrary, Mark


class TestStudentLibrary(unittest.TestCase):

    def setUp(self):
        self.student_library = StudentLibrary()

    def test_MinAVG(self):
        marks = ["4", "5", "3", "2", "4"]
        expected = 3.6  # Среднее арифметическое: (4+5+3+2+4)/5 = 3.6
        actual = self.student_library.MinAVG(marks)
        self.assertEqual(expected, actual)

    def test_GetCountTruancy(self):
        marks_list = [
            Mark(datetime(2024, 4, 1), "прогул"),
            Mark(datetime(2024, 4, 5), "прогул"),
            Mark(datetime(2024, 4, 12), "прогул")
        ]
        expected = [1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0]  # 3 прогула в апреле
        actual = self.student_library.GetCountTruancy(marks_list)
        self.assertEqual(expected, actual)

    def test_GetCountDisease(self):
        marks_list = [
            Mark(datetime(2024, 4, 3), "болезнь"),
            Mark(datetime(2024, 4, 7), "болезнь")
        ]
        expected = [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0]  # 2 болезни в апреле
        actual = self.student_library.GetCountDisease(marks_list)
        self.assertEqual(expected, actual)

    def test_GetStudNumber(self):
        expected = "2022.10.ИИИ"  # Номер студенческого билета
        actual = self.student_library.GetStudNumber(2022, 10, "Иванов Иван Иванович")
        self.assertEqual(expected, actual)

    @patch("your_module.choice")
    def test_GetMarks(self, mock_choice):
        now = datetime.now()
        mock_choice.side_effect = ["3", "прогул", "болезнь", "5", "4", "отсутствие", "2", "прогул", "3", "5"]
        students = ["Иванов", "Петров", "Сидоров"]
        generated_marks = self.student_library.GetMarks(now, students)
        self.assertEqual(30, len(generated_marks))  # 3 студента * 10 дней
        for mark in generated_marks:
            self.assertIn(mark.estimation, ["2", "3", "4", "5", "прогул", "болезнь", "отсутствие"])


if __name__ == '__main__':
    unittest.main()
