from datetime import datetime, timedelta
from random import choice
from typing import List


class Mark:
    def __init__(self, date: datetime, estimation: str):
        self.date = date
        self.estimation = estimation


class StudentLibrary:
    # 1) Вычисление среднего арифметического значения оценки в меньшую сторону
    def MinAVG(self, marks: List[str]) -> float:
        if not marks:
            raise ValueError("Marks list cannot be empty")

        total = sum(int(mark) for mark in marks if mark.isdigit())
        return total / len(marks)

    # 2) Вычисление количество прогулов за месяц за период
    def GetCountTruancy(self, marks: List[Mark]) -> List[int]:
        truancy_count = [0] * 12  # Счетчики прогулов по месяцам

        for mark in marks:
            if mark.estimation == "прогул":
                truancy_count[mark.date.month - 1] += 1

        return truancy_count

    # 3) Вычисление количество пропусков по болезни за месяц за период
    def GetCountDisease(self, marks: List[Mark]) -> List[int]:
        disease_count = [0] * 12  # Счетчики пропусков по болезни по месяцам

        for mark in marks:
            if mark.estimation == "болезнь":
                disease_count[mark.date.month - 1] += 1

        return disease_count

    # 4) Генерация номера студенческого билета в формате: yyyy.group.initial
    def GetStudNumber(self, year: int, group: int, fio: str) -> str:
        initials = ''.join(name[0] for name in fio.split())
        return f"{year}.{group}.{initials}"

    # 5) Генерация оценок на 10 дней вперед, начиная с текущей даты со списком переданных студентов
    def GetMarks(self, now: datetime, students: List[str]) -> List[Mark]:
        marks = []
        for student in students:
            for _ in range(10):
                mark_date = now + timedelta(days=_)
                estimation = choice(["2", "3", "4", "5", "прогул", "болезнь", "отсутствие"])
                marks.append(Mark(mark_date, estimation))
        return marks
########################################################################################################################
if __name__ == "__main__":
    # Создаем экземпляр класса StudentLibrary
    student_library = StudentLibrary()

    # Пример вызова функции MinAVG
    marks = ["4", "5", "3", "2", "4"]
    min_average = student_library.MinAVG(marks)
    print(f"Среднее арифметическое: {min_average}")

    # Пример вызова функции GetCountTruancy
    marks_list = [
        Mark(datetime(2024, 4, 1), "прогул"),
        Mark(datetime(2024, 4, 5), "прогул"),
        Mark(datetime(2024, 4, 12), "прогул")
    ]
    truancy_count = student_library.GetCountTruancy(marks_list)
    print("Количество прогулов за месяц:")
    for month, count in enumerate(truancy_count, start=1):
        print(f"Месяц {month}: {count}")

    # Пример вызова функции GetCountDisease
    marks_list2 = [
        Mark(datetime(2024, 4, 3), "болезнь"),
        Mark(datetime(2024, 4, 7), "болезнь")
    ]
    disease_count = student_library.GetCountDisease(marks_list2)
    print("Количество пропусков по болезни за месяц:")
    for month, count in enumerate(disease_count, start=1):
        print(f"Месяц {month}: {count}")

    # Пример вызова функции GetStudNumber
    stud_number = student_library.GetStudNumber(2022, 10, "Иванов Иван Иванович")
    print(f"Номер студенческого билета: {stud_number}")

    # Пример вызова функции GetMarks
    students = ["Иванов", "Петров", "Сидоров"]
    generated_marks = student_library.GetMarks(datetime.now(), students)
    print("Сгенерированные оценки для студентов:")
    for mark in generated_marks:
        print(f"Дата: {mark.date.strftime('%Y-%m-%d')}, Оценка: {mark.estimation}")
